package scs.map.sem9_paging.util.event;

public enum EntityChangeEventType {
    ADD,
    UPDATE,
    DELETE;
}
