package scs.map.sem9_paging;

public class Main {
    public static void main(String[] args) {
        //HelloApplication.main(args);
        MovieApplication.main(args);
    }
}
