package scs.map.sem9_paging.util.event;

public interface Event {
}
